# Telegram Storage Panel

Painel web + bot Telegram para usar um canal privado como backend de arquivos.

## Recursos

- Upload web em streaming (sem multipart e sem duplicar 2 GB em spool do framework)
- Telegram Bot API local
- Arquivos de até 1.990.000.000 bytes por upload (margem abaixo de 2000 MB)
- Catálogo PostgreSQL
- SHA-256 durante o upload
- Download via painel
- Exclusão sincronizada com o canal
- Bot com `/start`, `/help`, `/files`, `/stats`
- Documento enviado diretamente ao bot pode ser copiado para o canal
- Login por sessão HTTP-only e CSRF
- HTTPS automático via Caddy
- Docker Compose

## Pré-requisitos Telegram

1. Crie o bot com `@BotFather` e obtenha `BOT_TOKEN`.
2. Obtenha `api_id` e `api_hash` em `https://my.telegram.org`.
3. Crie um canal **privado**.
4. Adicione o bot como administrador com permissão para publicar e excluir mensagens.
5. Descubra o `chat_id` do canal, no formato `-100...`.
6. Descubra seu Telegram User ID e configure a whitelist do bot.

## Instalação

Ubuntu/Debian:

```bash
sudo ./install.sh
```

O instalador pede domínio, credenciais Telegram e usuário/senha do painel, instala Docker quando necessário, gera segredos e sobe os containers.

## Desenvolvimento

```bash
cp .env.example .env
docker compose up --build
```

## Segurança

- `.env` deve permanecer com `chmod 600`.
- O serviço `telegram-bot-api` fica somente na rede Docker interna.
- PostgreSQL não publica porta no host.
- O canal deve ser privado.
- Nunca compartilhe `BOT_TOKEN`, `api_hash` ou `.env`.

## Nota sobre a imagem da Bot API

O Compose usa `aiogram/telegram-bot-api`, uma imagem não oficial do servidor open-source `tdlib/telegram-bot-api`, para simplificar a instalação. Para ambientes de maior criticidade, recomenda-se construir a imagem diretamente do código oficial e fixar a versão/digest no Compose.
