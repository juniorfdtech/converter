from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings, get_settings
from app.core.security import new_csrf_token
from app.db.models import StoredFile
from app.db.session import get_db
from app.services.storage import store_request_body
from app.services.telegram import TelegramClient

router = APIRouter()


def require_user(request: Request) -> str:
    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Não autenticado")
    return str(user)


def require_csrf(request: Request) -> None:
    supplied = request.headers.get("x-csrf-token")
    if not supplied or supplied != request.session.get("csrf_token"):
        raise HTTPException(status_code=403, detail="CSRF inválido")


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    if request.session.get("user"):
        return RedirectResponse("/", status_code=303)
    csrf = request.session.get("csrf_token") or new_csrf_token()
    request.session["csrf_token"] = csrf
    flash = request.session.pop("flash", None)
    return request.app.state.templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"csrf_token": csrf, "flash": flash},
    )


@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: AsyncSession = Depends(get_db)):
    try:
        user = require_user(request)
    except HTTPException:
        return RedirectResponse("/login", status_code=303)

    files_count = await db.scalar(select(func.count(StoredFile.id)).where(StoredFile.is_deleted.is_(False))) or 0
    total_bytes = await db.scalar(select(func.coalesce(func.sum(StoredFile.size_bytes), 0)).where(StoredFile.is_deleted.is_(False))) or 0
    recent = (await db.scalars(select(StoredFile).where(StoredFile.is_deleted.is_(False)).order_by(StoredFile.created_at.desc()).limit(10))).all()

    return request.app.state.templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "user": user,
            "csrf_token": request.session["csrf_token"],
            "files_count": files_count,
            "total_bytes": int(total_bytes),
            "recent": recent,
            "max_upload_bytes": get_settings().max_upload_bytes,
        },
    )


@router.get("/files", response_class=HTMLResponse)
async def files_page(request: Request, q: str = Query(default="", max_length=120), db: AsyncSession = Depends(get_db)):
    try:
        user = require_user(request)
    except HTTPException:
        return RedirectResponse("/login", status_code=303)

    stmt = select(StoredFile).where(StoredFile.is_deleted.is_(False))
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(StoredFile.original_name.ilike(like), StoredFile.sha256.ilike(like)))
    files = (await db.scalars(stmt.order_by(StoredFile.created_at.desc()).limit(500))).all()
    return request.app.state.templates.TemplateResponse(
        request=request,
        name="files.html",
        context={"user": user, "csrf_token": request.session["csrf_token"], "files": files, "q": q},
    )


@router.put("/api/files/upload")
async def upload_file(
    request: Request,
    filename: str = Query(..., min_length=1, max_length=512),
    db: AsyncSession = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    user = require_user(request)
    require_csrf(request)
    telegram: TelegramClient = request.app.state.telegram
    record = await store_request_body(request, db, telegram, settings, filename, user)
    return {
        "id": str(record.id),
        "name": record.original_name,
        "size": record.size_bytes,
        "sha256": record.sha256,
        "message_id": record.telegram_message_id,
    }


@router.delete("/api/files/{file_id}")
async def delete_file(file_id: UUID, request: Request, db: AsyncSession = Depends(get_db)):
    require_user(request)
    require_csrf(request)
    record = await db.get(StoredFile, file_id)
    if not record or record.is_deleted:
        raise HTTPException(status_code=404, detail="Arquivo não encontrado")

    telegram: TelegramClient = request.app.state.telegram
    await telegram.delete_message(record.telegram_chat_id, record.telegram_message_id)
    record.is_deleted = True
    record.deleted_at = datetime.now(timezone.utc)
    await db.commit()
    return {"ok": True}


@router.get("/api/files/{file_id}/download")
async def download_file(file_id: UUID, request: Request, db: AsyncSession = Depends(get_db)):
    require_user(request)
    record = await db.get(StoredFile, file_id)
    if not record or record.is_deleted:
        raise HTTPException(status_code=404, detail="Arquivo não encontrado")

    telegram: TelegramClient = request.app.state.telegram
    info = await telegram.get_file(record.telegram_file_id)
    file_path = info.get("file_path")
    if not file_path:
        raise HTTPException(status_code=502, detail="Telegram não retornou file_path")

    headers = {
        "Content-Disposition": f'attachment; filename="{record.original_name.replace(chr(34), "_")}"',
        "X-Content-Type-Options": "nosniff",
    }
    return StreamingResponse(
        telegram.stream_file(file_path),
        media_type=record.mime_type,
        headers=headers,
    )


@router.get("/health")
async def health(request: Request, db: AsyncSession = Depends(get_db)):
    await db.execute(select(1))
    me = await request.app.state.telegram.get_me()
    return {"status": "ok", "bot": me.get("username")}
