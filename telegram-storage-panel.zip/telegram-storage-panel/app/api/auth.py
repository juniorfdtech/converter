from fastapi import APIRouter, Form, Request
from fastapi.responses import RedirectResponse

from app.core.config import get_settings
from app.core.security import new_csrf_token, verify_password

router = APIRouter()
settings = get_settings()


@router.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...), csrf_token: str = Form(...)):
    session_csrf = request.session.get("csrf_token")
    if not session_csrf or csrf_token != session_csrf:
        request.session["flash"] = "Sessão inválida. Tente novamente."
        return RedirectResponse("/login", status_code=303)

    if username != settings.admin_username or not verify_password(password, settings.admin_password_hash):
        request.session["flash"] = "Usuário ou senha inválidos."
        return RedirectResponse("/login", status_code=303)

    request.session.clear()
    request.session["user"] = username
    request.session["csrf_token"] = new_csrf_token()
    return RedirectResponse("/", status_code=303)


@router.post("/logout")
async def logout(request: Request, csrf_token: str = Form(...)):
    if csrf_token != request.session.get("csrf_token"):
        return RedirectResponse("/", status_code=303)
    request.session.clear()
    return RedirectResponse("/login", status_code=303)
