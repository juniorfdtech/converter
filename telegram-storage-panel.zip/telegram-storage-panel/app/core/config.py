from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Telegram Storage"
    app_env: str = "production"
    secret_key: str = Field(min_length=32)
    database_url: str = "postgresql+asyncpg://telegram:telegram@postgres:5432/telegram_storage"

    admin_username: str = "admin"
    admin_password_hash: str

    telegram_bot_token: str
    telegram_api_base: str = "http://telegram-bot-api:8081"
    telegram_channel_id: int
    telegram_allowed_user_ids: str = ""

    upload_dir: Path = Path("/data/uploads")
    max_upload_bytes: int = 1_990_000_000
    upload_chunk_bytes: int = 8 * 1024 * 1024
    keep_local_uploads: bool = False

    session_cookie_name: str = "tgstorage_session"
    session_max_age: int = 12 * 60 * 60
    secure_cookies: bool = True

    @field_validator("telegram_allowed_user_ids")
    @classmethod
    def normalize_allowed_users(cls, value: str) -> str:
        return ",".join(part.strip() for part in value.split(",") if part.strip())

    @property
    def allowed_user_ids(self) -> set[int]:
        result: set[int] = set()
        for value in self.telegram_allowed_user_ids.split(","):
            value = value.strip()
            if value:
                result.add(int(value))
        return result


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
