from __future__ import annotations

import hashlib
import mimetypes
import os
import re
from pathlib import Path
from uuid import uuid4

from fastapi import HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings
from app.db.models import StoredFile
from app.services.telegram import TelegramClient

_FILENAME_SAFE = re.compile(r"[^A-Za-z0-9._()\- ]+")


def sanitize_filename(filename: str) -> str:
    name = Path(filename).name.strip().replace("\x00", "")
    name = _FILENAME_SAFE.sub("_", name)
    name = name[:240].strip(" .")
    return name or "arquivo.bin"


async def store_request_body(
    request: Request,
    db: AsyncSession,
    telegram: TelegramClient,
    settings: Settings,
    filename: str,
    uploaded_by: str,
) -> StoredFile:
    filename = sanitize_filename(filename)
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            declared_size = int(content_length)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Content-Length inválido.") from exc
        if declared_size > settings.max_upload_bytes:
            raise HTTPException(status_code=413, detail="Arquivo excede o limite configurado.")

    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = settings.upload_dir / uuid4().hex
    temp_dir.mkdir(parents=True, exist_ok=False)
    temp_path = temp_dir / filename
    digest = hashlib.sha256()
    size = 0

    try:
        with temp_path.open("xb") as output:
            async for chunk in request.stream():
                if not chunk:
                    continue
                size += len(chunk)
                if size > settings.max_upload_bytes:
                    raise HTTPException(status_code=413, detail="Arquivo excede o limite configurado.")
                digest.update(chunk)
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())

        if size == 0:
            raise HTTPException(status_code=400, detail="Arquivo vazio.")

        caption = f"📦 {filename}\n🔐 SHA-256: {digest.hexdigest()}"
        message = await telegram.send_document_local(temp_path, filename, caption)
        document = message["document"]
        mime_type = document.get("mime_type") or mimetypes.guess_type(filename)[0] or "application/octet-stream"

        record = StoredFile(
            original_name=filename,
            mime_type=mime_type,
            size_bytes=size,
            sha256=digest.hexdigest(),
            telegram_chat_id=settings.telegram_channel_id,
            telegram_message_id=int(message["message_id"]),
            telegram_file_id=document["file_id"],
            telegram_file_unique_id=document["file_unique_id"],
            uploaded_by=uploaded_by,
        )
        db.add(record)
        await db.commit()
        await db.refresh(record)
        return record
    except Exception:
        await db.rollback()
        raise
    finally:
        if not settings.keep_local_uploads:
            temp_path.unlink(missing_ok=True)
            temp_dir.rmdir()
