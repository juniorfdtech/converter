from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, AsyncIterator

import httpx

from app.core.config import Settings


class TelegramAPIError(RuntimeError):
    pass


class TelegramClient:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.base = f"{settings.telegram_api_base.rstrip('/')}/bot{settings.telegram_bot_token}"
        self.file_base = f"{settings.telegram_api_base.rstrip('/')}/file/bot{settings.telegram_bot_token}"
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(connect=15, read=1800, write=1800, pool=30))

    async def close(self) -> None:
        await self._client.aclose()

    async def call(self, method: str, data: dict[str, Any] | None = None) -> Any:
        response = await self._client.post(f"{self.base}/{method}", data=data or {})
        payload = response.json()
        if not response.is_success or not payload.get("ok"):
            raise TelegramAPIError(payload.get("description", f"Telegram HTTP {response.status_code}"))
        return payload.get("result")

    async def get_me(self) -> dict[str, Any]:
        return await self.call("getMe")

    async def send_document_local(self, path: Path, original_name: str, caption: str | None = None) -> dict[str, Any]:
        data = {
            "chat_id": str(self.settings.telegram_channel_id),
            "document": f"file://{path}",
            "disable_content_type_detection": "false",
        }
        if caption:
            data["caption"] = caption[:1024]
        result = await self.call("sendDocument", data)
        document = result.get("document")
        if not document:
            raise TelegramAPIError("Telegram não retornou o objeto document.")
        return result

    async def send_document_by_file_id(self, file_id: str, caption: str | None = None) -> dict[str, Any]:
        data = {"chat_id": str(self.settings.telegram_channel_id), "document": file_id}
        if caption:
            data["caption"] = caption[:1024]
        return await self.call("sendDocument", data)

    async def send_message(self, chat_id: int, text: str) -> dict[str, Any]:
        return await self.call("sendMessage", {"chat_id": str(chat_id), "text": text})

    async def delete_message(self, chat_id: int, message_id: int) -> bool:
        return bool(await self.call("deleteMessage", {"chat_id": str(chat_id), "message_id": str(message_id)}))

    async def get_file(self, file_id: str) -> dict[str, Any]:
        return await self.call("getFile", {"file_id": file_id})

    async def get_updates(self, offset: int | None, timeout: int = 30) -> list[dict[str, Any]]:
        data: dict[str, Any] = {"timeout": str(timeout), "allowed_updates": '["message"]'}
        if offset is not None:
            data["offset"] = str(offset)
        return await self.call("getUpdates", data)

    async def stream_file(self, file_path: str) -> AsyncIterator[bytes]:
        async with self._client.stream("GET", f"{self.file_base}/{file_path.lstrip('/')}") as response:
            response.raise_for_status()
            async for chunk in response.aiter_bytes(1024 * 1024):
                yield chunk

    async def wait_until_ready(self, attempts: int = 60, interval: float = 2.0) -> None:
        last_error: Exception | None = None
        for _ in range(attempts):
            try:
                await self.get_me()
                return
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                await asyncio.sleep(interval)
        raise TelegramAPIError(f"Telegram Bot API indisponível: {last_error}")
