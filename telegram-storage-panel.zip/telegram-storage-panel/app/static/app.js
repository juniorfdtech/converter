(() => {
  const formatBytes = (bytes) => {
    let value = Number(bytes || 0);
    const units = ["B","KB","MB","GB","TB"];
    let i = 0;
    while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
    return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
  };
  document.querySelectorAll("[data-bytes]").forEach(el => el.textContent = formatBytes(el.dataset.bytes));

  const dropzone = document.getElementById("dropzone");
  const input = document.getElementById("file-input");
  const list = document.getElementById("upload-list");
  if (dropzone && input && list) {
    dropzone.addEventListener("click", () => input.click());
    ["dragenter","dragover"].forEach(evt => dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.add("drag"); }));
    ["dragleave","drop"].forEach(evt => dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.remove("drag"); }));
    dropzone.addEventListener("drop", e => uploadAll([...e.dataTransfer.files]));
    input.addEventListener("change", () => uploadAll([...input.files]));
  }

  function uploadAll(files) { files.reduce((p, file) => p.then(() => upload(file)), Promise.resolve()); }
  function upload(file) {
    return new Promise(resolve => {
      const row = document.createElement("div");
      row.className = "upload-item";
      row.innerHTML = `<div class="upload-meta"><strong></strong><span>0%</span></div><div class="progress"><span></span></div><small class="muted"></small>`;
      row.querySelector("strong").textContent = file.name;
      const pct = row.querySelector(".upload-meta span");
      const bar = row.querySelector(".progress span");
      const note = row.querySelector("small");
      list.prepend(row);

      const xhr = new XMLHttpRequest();
      xhr.open("PUT", `/api/files/upload?filename=${encodeURIComponent(file.name)}`);
      xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
      xhr.setRequestHeader("X-CSRF-Token", window.CSRF_TOKEN || "");
      xhr.upload.onprogress = e => {
        if (!e.lengthComputable) return;
        const value = Math.round((e.loaded / e.total) * 100);
        pct.textContent = `${value}%`;
        bar.style.width = `${value}%`;
        note.textContent = `${formatBytes(e.loaded)} / ${formatBytes(e.total)}`;
      };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          pct.textContent = "Concluído"; bar.style.width = "100%"; note.textContent = "Arquivo armazenado no Telegram.";
        } else {
          pct.textContent = "Erro"; note.textContent = parseError(xhr.responseText);
        }
        resolve();
      };
      xhr.onerror = () => { pct.textContent = "Erro"; note.textContent = "Falha de rede."; resolve(); };
      xhr.send(file);
    });
  }
  function parseError(body) { try { return JSON.parse(body).detail || body; } catch { return body || "Erro desconhecido"; } }

  document.querySelectorAll(".delete-file").forEach(button => button.addEventListener("click", async () => {
    if (!confirm("Excluir este arquivo do canal Telegram e do catálogo?")) return;
    const id = button.dataset.id;
    const response = await fetch(`/api/files/${id}`, {method:"DELETE", headers:{"X-CSRF-Token":window.CSRF_TOKEN || ""}});
    if (response.ok) document.querySelector(`[data-row-id="${id}"]`)?.remove();
    else alert(parseError(await response.text()));
  }));
})();
