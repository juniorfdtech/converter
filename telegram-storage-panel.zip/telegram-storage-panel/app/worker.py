from __future__ import annotations

import asyncio
import logging

from sqlalchemy import select

from app.core.config import get_settings
from app.db.models import BotState, StoredFile
from app.db.session import SessionLocal
from app.services.telegram import TelegramClient, TelegramAPIError

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("telegram-worker")
settings = get_settings()


async def get_offset() -> int | None:
    async with SessionLocal() as db:
        state = await db.get(BotState, "update_offset")
        return int(state.value) if state else None


async def save_offset(offset: int) -> None:
    async with SessionLocal() as db:
        state = await db.get(BotState, "update_offset")
        if state:
            state.value = str(offset)
        else:
            db.add(BotState(key="update_offset", value=str(offset)))
        await db.commit()


async def handle_document(client: TelegramClient, message: dict) -> None:
    chat_id = int(message["chat"]["id"])
    user_id = int(message.get("from", {}).get("id", 0))
    if settings.allowed_user_ids and user_id not in settings.allowed_user_ids:
        return

    document = message.get("document")
    if not document:
        return

    name = document.get("file_name") or "arquivo.bin"
    sent = await client.send_document_by_file_id(document["file_id"], f"📥 Enviado pelo bot\n📦 {name}")
    stored_doc = sent["document"]

    async with SessionLocal() as db:
        db.add(
            StoredFile(
                original_name=name,
                mime_type=document.get("mime_type") or "application/octet-stream",
                size_bytes=int(document.get("file_size") or 0),
                sha256=None,
                telegram_chat_id=settings.telegram_channel_id,
                telegram_message_id=int(sent["message_id"]),
                telegram_file_id=stored_doc["file_id"],
                telegram_file_unique_id=stored_doc["file_unique_id"],
                uploaded_by=f"telegram:{user_id}",
            )
        )
        await db.commit()

    await client.send_message(chat_id, f"✅ Arquivo armazenado no canal.\n📦 {name}")


async def handle_command(client: TelegramClient, message: dict) -> bool:
    text = (message.get("text") or "").strip()
    if not text.startswith("/"):
        return False

    chat_id = int(message["chat"]["id"])
    user_id = int(message.get("from", {}).get("id", 0))
    if settings.allowed_user_ids and user_id not in settings.allowed_user_ids:
        return True

    command = text.split()[0].split("@")[0].lower()
    if command in {"/start", "/help"}:
        await client.send_message(
            chat_id,
            "📦 Telegram Storage\n\nEnvie um documento para armazená-lo no canal.\n\nComandos:\n/files - últimos arquivos\n/stats - estatísticas\n/help - ajuda",
        )
    elif command == "/stats":
        async with SessionLocal() as db:
            rows = (await db.scalars(select(StoredFile).where(StoredFile.is_deleted.is_(False)))).all()
        total = sum(item.size_bytes for item in rows)
        await client.send_message(chat_id, f"📊 Arquivos: {len(rows)}\n💾 Tamanho catalogado: {format_bytes(total)}")
    elif command == "/files":
        async with SessionLocal() as db:
            rows = (await db.scalars(select(StoredFile).where(StoredFile.is_deleted.is_(False)).order_by(StoredFile.created_at.desc()).limit(10))).all()
        if not rows:
            await client.send_message(chat_id, "Nenhum arquivo cadastrado.")
        else:
            body = "\n".join(f"• {item.original_name} — {format_bytes(item.size_bytes)}" for item in rows)
            await client.send_message(chat_id, f"📁 Últimos arquivos:\n\n{body}")
    return True


def format_bytes(value: int) -> str:
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


async def main() -> None:
    client = TelegramClient(settings)
    await client.wait_until_ready()
    offset = await get_offset()
    log.info("Worker iniciado. Offset=%s", offset)
    try:
        while True:
            try:
                updates = await client.get_updates(offset, timeout=30)
                for update in updates:
                    update_id = int(update["update_id"])
                    message = update.get("message")
                    if message:
                        handled = await handle_command(client, message)
                        if not handled and message.get("document"):
                            await handle_document(client, message)
                    offset = update_id + 1
                    await save_offset(offset)
            except TelegramAPIError as exc:
                log.warning("Erro Telegram: %s", exc)
                await asyncio.sleep(3)
            except Exception:
                log.exception("Erro inesperado no worker")
                await asyncio.sleep(3)
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
