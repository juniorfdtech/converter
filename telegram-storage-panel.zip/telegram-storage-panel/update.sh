#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/telegram-storage"
cd "$APP_DIR"
git pull --ff-only
docker compose build web bot-worker
docker compose up -d --remove-orphans
docker image prune -f >/dev/null
printf 'Atualização concluída.\n'
