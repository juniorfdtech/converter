#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/telegram-storage"
REPO_URL_DEFAULT="https://github.com/juniorfdtech/telegram-storage.git"

info(){ printf '\033[1;34m[INFO]\033[0m %s\n' "$*"; }
ok(){ printf '\033[1;32m[OK]\033[0m %s\n' "$*"; }
fail(){ printf '\033[1;31m[ERRO]\033[0m %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || fail "Execute como root: sudo bash install.sh"
command -v apt-get >/dev/null 2>&1 || fail "Instalador inicial suporta Ubuntu/Debian."

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl git openssl python3

if ! command -v docker >/dev/null 2>&1; then
  info "Instalando Docker Engine..."
  curl -fsSL https://get.docker.com | sh
fi
docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 não encontrado."

read -rp "Domínio do painel (ex.: storage.exemplo.com): " DOMAIN
read -rp "Telegram Bot Token: " TELEGRAM_BOT_TOKEN
read -rp "Telegram API ID (my.telegram.org): " TELEGRAM_API_ID
read -rp "Telegram API Hash: " TELEGRAM_API_HASH
read -rp "ID do canal privado (-100...): " TELEGRAM_CHANNEL_ID
read -rp "Telegram user IDs autorizados, separados por vírgula: " TELEGRAM_ALLOWED_USER_IDS
read -rp "Usuário administrador [admin]: " ADMIN_USERNAME
ADMIN_USERNAME="${ADMIN_USERNAME:-admin}"
while true; do
  read -rsp "Senha do painel (mín. 12 caracteres): " ADMIN_PASSWORD; echo
  [[ ${#ADMIN_PASSWORD} -ge 12 ]] && break
  echo "Senha muito curta."
done

SECRET_KEY="$(openssl rand -hex 48)"
POSTGRES_PASSWORD="$(openssl rand -hex 32)"
ADMIN_PASSWORD_HASH="$(ADMIN_PASSWORD="$ADMIN_PASSWORD" python3 - <<'PY'
import base64, hashlib, os, secrets
password=os.environ['ADMIN_PASSWORD'].encode()
salt=secrets.token_bytes(16)
n,r,p=16384,8,1
key=hashlib.scrypt(password,salt=salt,n=n,r=r,p=p,dklen=32)
print('$'.join(['scrypt',str(n),str(r),str(p),base64.urlsafe_b64encode(salt).decode(),base64.urlsafe_b64encode(key).decode()]))
PY
)"
unset ADMIN_PASSWORD

if [[ -f ./docker-compose.yml && -d ./app ]]; then
  SOURCE_DIR="$(pwd)"
  mkdir -p "$APP_DIR"
  cp -a "$SOURCE_DIR"/. "$APP_DIR"/
else
  read -rp "URL do repositório [${REPO_URL_DEFAULT}]: " REPO_URL
  REPO_URL="${REPO_URL:-$REPO_URL_DEFAULT}"
  rm -rf "$APP_DIR"
  git clone --depth=1 "$REPO_URL" "$APP_DIR"
fi
cd "$APP_DIR"

cat > .env <<ENV
APP_NAME=Telegram Storage
APP_ENV=production
SECRET_KEY=${SECRET_KEY}
DATABASE_URL=postgresql+asyncpg://telegram:${POSTGRES_PASSWORD}@postgres:5432/telegram_storage
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
ADMIN_USERNAME=${ADMIN_USERNAME}
ADMIN_PASSWORD_HASH=${ADMIN_PASSWORD_HASH}
TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
TELEGRAM_API_ID=${TELEGRAM_API_ID}
TELEGRAM_API_HASH=${TELEGRAM_API_HASH}
TELEGRAM_API_BASE=http://telegram-bot-api:8081
TELEGRAM_CHANNEL_ID=${TELEGRAM_CHANNEL_ID}
TELEGRAM_ALLOWED_USER_IDS=${TELEGRAM_ALLOWED_USER_IDS}
DOMAIN=${DOMAIN}
MAX_UPLOAD_BYTES=1990000000
UPLOAD_DIR=/data/uploads
KEEP_LOCAL_UPLOADS=false
SECURE_COOKIES=true
ENV
chmod 600 .env

info "Desconectando o bot do Bot API cloud antes de migrar para a API local..."
curl -fsS -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/logOut" >/dev/null || true

info "Construindo e iniciando serviços..."
docker compose pull postgres telegram-bot-api caddy
docker compose build web bot-worker
docker compose up -d

info "Aguardando health check..."
for _ in $(seq 1 60); do
  if curl -kfsS --resolve "${DOMAIN}:443:127.0.0.1" "https://${DOMAIN}/health" >/dev/null 2>&1; then
    ok "Painel disponível em https://${DOMAIN}"
    echo "Usuário: ${ADMIN_USERNAME}"
    echo "Diretório: ${APP_DIR}"
    exit 0
  fi
  sleep 2
done

docker compose ps
fail "Serviços iniciaram, mas o health check ainda não respondeu. Verifique: cd ${APP_DIR} && docker compose logs -f"
